# Xiaozhaobao Career Advisor

基于校招宝（xiaozhaobao.com.cn）真实聚合数据的校招求职顾问专家。帮应届生查岗位、看攻略、问薪资、练笔试题，覆盖秋招、春招、实习、提前批全周期。

## 类型

Agent 型（单个 AI 专家）

## 功能

- **岗位查询**：按目标岗位/城市/批次/行业/届别查真实在招岗位，附截止时间与投递方式
- **求职攻略**：30 大热门岗位的 6 大板块攻略（岗位概述/笔试/面试/薪资/FAQ/说明书）
- **薪资参考**：基于公开爆料与截尾聚合的薪资区间（千元/月），注明样本量
- **笔试练习**：按岗位组卷（8 笔试 + 2 面试），引导作答

数据能力由内置技能 `xiaozhaobao-recruit` 提供（脚本直调校招宝公开 API，实时数据，零依赖）。

## 使用示例

- 帮我找 2027 届算法工程师的秋招岗位
- 产品经理岗位的笔试面试一般考什么？
- 腾讯校招薪资大概什么水平？

## 头像

头像已自动生成在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

将专家包目录放到专家目录下：

```
C:\Users\周凯\.workbuddy\plugins\marketplaces\my-experts\plugins/xiaozhaobao-career-advisor/
```

然后运行注册命令使其可见：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
zip -r xiaozhaobao-career-advisor.zip xiaozhaobao-career-advisor/
```
