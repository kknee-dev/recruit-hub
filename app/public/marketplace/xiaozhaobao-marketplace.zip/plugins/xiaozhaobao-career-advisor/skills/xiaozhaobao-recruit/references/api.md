# 校招宝 API 文档（公开接口）

> API 地址由 `xzb.py` 自动探测（按序取第一个可用）：环境变量 `XZB_API_BASE` → `https://xiaozhaobao.com.cn`（正式域名）→ `http://106.55.103.60:3600`（线上）→ `http://localhost:3600`（本地）。
> 公开接口无需鉴权。管理接口 `/api/admin/*` 需要 ADMIN_KEY，**严禁调用**。

## 1. 招聘搜索 `GET /api/jobs`

查询在招岗位，支持多条件组合筛选 + 分页。

| 参数 | 类型 | 说明 |
|---|---|---|
| `q` | string | 关键词，模糊匹配**公司/岗位/行业**（岗位词用此参数，无 `position` 参数） |
| `city` | string | 城市（如 上海，支持逗号多选） |
| `batch` | string | 批次（实习/秋招/春招/提前批/暑期实习…） |
| `industry` | string | 行业（互联网/金融/机械制造…） |
| `grad_year` | string | 届别（如 2027） |
| `company_type` | string | 企业类型（民企/央国企/政府事业单位…） |
| `page` / `size` | int | 分页；`size` 上限 50（脚本 --limit 会截断到 50） |
| `sort` | string | `deadline` 按截止时间升序 / `fresh` 按最新发现 |

> ⚠️ 接口**没有** `position` / `keyword` / `limit` 参数名，岗位词用 `q`，条数用 `size`。

响应：
```json
{
  "total": 9279, "page": 1, "size": 20,
  "list": [
    {
      "id": 68291, "company": "上海国际仲裁中心", "company_type": "政府/事业单位",
      "batch": "实习", "industry": "公共管理", "position": "上海国际仲裁中心实习项目",
      "education": "本科, 硕士, 博士", "grad_year": "2027", "city": "上海",
      "publish_date": "2026-08-06", "deadline": "2026-08-31",
      "exam": "未明确", "notice_url": "https://…", "notice_summary": null,
      "source": "飞书表格", "source_url": "https://…", "first_seen": "2026-08-06"
    }
  ]
}
```

## 2. 岗位详情 `GET /api/jobs/:id`

响应：
```json
{
  "job": { "…同列表字段…", "apply_url": "https://投递链接(可能为空,会员权益)" },
  "tier": "...", "locked": false, "fav": false, "track": false
}
```

> `apply_url` 为空时表示投递链接为注册会员权益，如实说明，不承诺免费。

## 3. 攻略目录 `GET /api/guides`

响应：`{"list": [{"name": "算法工程师", "job_count": 1878, "gcount": 6, "practiceN": 100, "hasPractice": true, "slug": "algorithm-engineer"}, …]}`

## 4. 单岗位攻略 `GET /api/guides/:slug`

- `:slug` 用英文 slug（如 `algorithm-engineer`），脚本已内置中文名→slug 映射。
- 响应 `guides[]` 含 6 个 stage：
  - `overview`（岗位概述）、`written`（笔试攻略）、`interview`（面试攻略）
  - `salary`（薪资情况）、`faq`（常见问题）、`说明书`（岗位说明书）
- 每项 `content` 为 Markdown 正文。

## 5. 薪资参考 `GET /api/offer/reference`

| 参数 | 说明 |
|---|---|
| `position` | 中文岗位名（如 算法工程师） |
| `company` | 公司（可选） |
| `city` | 城市（可选） |

响应：
```json
{"list": [
  {"id": 23, "company": "百度", "position": "算法工程师", "education": "硕士",
   "city": null, "tier": "全部", "salary_min": 48, "salary_max": 70,
   "grad_year": "2025", "source": "…", "source_url": null}
]}
```

> `salary_min/max` 单位：**千元/月**（48 = 48k/月）。数据来自公开爆料与薪资汇总，仅供参考。

## 6. 练习组卷 `GET /api/practice/paper`

| 参数 | 说明 |
|---|---|
| `position` | 中文岗位名 |
| `size` | 题量（默认 10 = 8 笔试 + 2 面试） |

响应：
```json
{"position": "算法工程师", "intro": "…", "job_count": 1249, "size": 2,
 "written": 2, "interview": 0,
 "questions": [{"id": 3626, "q_type": "多选", "stem": "…",
   "options": ["…"], "exam_stage": "笔试", "position": "算法工程师"}]}
```

> **题目不返回答案**（answer/rubric 字段被剥离）——展示题干引导作答，判分与解析在站内完成。

## 7. 筛选项字典 `GET /api/meta`

响应：`{"total": N, "batch": [...], "company_type": [...], "industry": [...], "city": [...], "grad_year": [...], …}`

---

## 安全红线

- 只调用上述公开接口；`/api/admin/*`、`/api/auth/*`、`/api/practice/paper/submit` 等需要密钥/登录的接口**一律不调用**。
- 脚本不内置、不读取 ADMIN_KEY。
