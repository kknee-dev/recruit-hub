#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""xzb.py —— 校招宝公开 API 客户端（Python 标准库，零依赖）。

用法：
  python3 xzb.py jobs     [--position 岗位] [--city 城市] [--batch 批次]
                           [--industry 行业] [--grad-year 届别] [--keyword 关键词] [--limit N]
  python3 xzb.py detail   --id <job_id>
  python3 xzb.py guide    --position <中文岗位名>
  python3 xzb.py guides
  python3 xzb.py salary   --position <中文岗位名> [--company 公司] [--city 城市]
  python3 xzb.py paper    --position <中文岗位名> [--size 10]
  python3 xzb.py meta

环境变量：XZB_API_BASE 覆盖 API 地址（默认自动探测）。
公开接口无需鉴权。严禁访问 /api/admin/*。
"""
import argparse
import concurrent.futures
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

def resolve_base():
    """解析 API 地址：环境变量优先，否则按顺序探测候选地址，第一个可用的生效。
    顺序：正式域名（备案完成后）→ 线上 IP → 本地。保证发布后开箱即用。"""
    env_base = os.environ.get("XZB_API_BASE", "").strip()
    if env_base:
        return env_base.rstrip("/")
    for cand in ("https://xiaozhaobao.com.cn",
                 "http://106.55.103.60:3600",
                 "http://localhost:3600"):
        try:
            req = urllib.request.Request(cand + "/api/meta",
                                         headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=5) as r:
                if r.status == 200:
                    return cand
        except Exception:
            continue
    return "https://xiaozhaobao.com.cn"


BASE = resolve_base()

# 站内浏览地址（给用户点的链接）：正式域名优先，否则线上直连；本地调试时仍是 BASE
SITE_LINK = os.environ.get("XZB_SITE_BASE", "https://xiaozhaobao.com.cn").rstrip("/")
if "localhost" in BASE or "127.0.0.1" in BASE:
    SITE_LINK = BASE

# 中文岗位名 → slug（与站内 position_slugs.js 一致，仅列攻略接口所需）
NAME_TO_SLUG = {
    '产品经理': 'product-manager', '人力资源': 'human-resources',
    '化工材料': 'chemical-materials', '医药生物': 'biopharma',
    '咨询顾问': 'consulting', '土木建筑': 'civil-construction',
    '市场营销': 'marketing', '教师教研': 'education-teacher',
    '数据分析': 'data-analytics', '机械工程': 'mechanical-engineering',
    '校园大使': 'campus-ambassador', '法务合规': 'legal-compliance',
    '测试工程师': 'test-engineer', '生产制造': 'manufacturing',
    '电气工程': 'electrical-engineering', '硬件与芯片': 'hardware-chip',
    '科研岗': 'research-scientist', '算法工程师': 'algorithm-engineer',
    '管培生': 'management-trainee', '编辑与传媒': 'editor-media',
    '行政职能': 'admin-functions', '设计': 'design',
    '财务会计': 'finance-accounting', '质量管理': 'quality-management',
    '软件开发': 'software-development', '运维与IT': 'devops-it',
    '运营': 'operations', '采购供应链': 'procurement-supply-chain',
    '金融与银行': 'finance-banking', '销售': 'sales',
    '品牌经理': 'brand-manager', '前端开发': 'frontend-developer',
    '技术支持': 'tech-support',
}


def get(path, params=None, timeout=20):
    """GET JSON；非 2xx 抛异常并携带服务端信息。"""
    url = BASE + path
    if params:
        clean = {k: v for k, v in params.items() if v not in (None, "")}
        if clean:
            url += "?" + urllib.parse.urlencode(clean)
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode("utf-8", errors="replace")[:500]
        except Exception:
            pass
        raise SystemExit(f"HTTP {e.code} {e.reason}: {detail}")
    except urllib.error.URLError as e:
        raise SystemExit(f"网络错误: {e.reason}（检查 XZB_API_BASE 是否可达）")
    return json.loads(raw)


def fmt_job(j):
    parts = []
    if j.get("company"):
        parts.append(f"{j['company']} | {j.get('position') or ''}")
    if j.get("city"):
        parts.append(j["city"])
    if j.get("batch"):
        parts.append(j["batch"])
    if j.get("grad_year"):
        parts.append(f"{j['grad_year']}届")
    if j.get("deadline"):
        parts.append(f"截止 {j['deadline']}")
    return " | ".join(parts)


def fetch_apply_url(job_id):
    """并发取单条岗位详情中的投递链接（列表接口不含 apply_url，需详情接口）。失败返回 None。"""
    try:
        data = get(f"/api/jobs/{job_id}", timeout=8)
        return (data.get("job") or {}).get("apply_url") or None
    except Exception:
        return None


def cmd_jobs(a):
    # 注意：/api/jobs 无 position 精确参数，用 q 关键词（匹配公司/岗位/行业）+ size 分页
    q = a.position or a.keyword or None
    size = min(a.limit or 20, 50)  # 接口 size 上限 50
    data = get("/api/jobs", {
        "q": q, "city": a.city, "batch": a.batch,
        "industry": a.industry, "grad_year": a.grad_year,
        "size": size,
    })
    rows = data.get("list") or []
    print(f"共 {data.get('total', 0)} 条在招岗位，显示前 {len(rows)} 条：\n")

    # 并发补齐每条投递链接（列表接口不含 apply_url，需详情接口；默认 8 线程）
    workers = max(4, min(12, (len(rows) + 3) // 4))
    urls = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        future_map = {ex.submit(fetch_apply_url, j["id"]): j["id"] for j in rows if j.get("id")}
        for fut in concurrent.futures.as_completed(future_map):
            urls[future_map[fut]] = fut.result()

    for i, j in enumerate(rows, 1):
        print(f"{i}. {fmt_job(j)}")
        apply_url = urls.get(j.get("id"))
        if apply_url:
            print(f"   投递: {apply_url}")
        if j.get("notice_url"):
            print(f"   公告: {j['notice_url']}")
    print(f"\n👉 更多岗位与投递入口，请到校招宝查看更多：{SITE_LINK}")
    if q:
        search = SITE_LINK + "/?q=" + urllib.parse.quote(q)
        print(f"   直达搜索「{q}」：{search}")
    print("   提示：部分投递链接为校招宝注册会员权益，注册赠送 15 天免费试用；投递前请以企业官方公告为准。")
    if not rows:
        print("未命中，可调整筛选条件或换一种岗位说法。")


def cmd_detail(a):
    data = get(f"/api/jobs/{a.id}")
    job = data.get("job") or {}
    print(f"【{job.get('company') or ''}】{job.get('position') or ''}")
    print(f"  城市: {job.get('city') or '-'} | 批次: {job.get('batch') or '-'} | 行业: {job.get('industry') or '-'}")
    print(f"  学历: {job.get('education') or '-'} | 届别: {job.get('grad_year') or '-'}届")
    print(f"  发布时间: {job.get('publish_date') or '-'} | 截止: {job.get('deadline') or '-'}")
    if job.get("exam"):
        print(f"  笔试情况: {job['exam']}")
    if job.get("apply_url"):
        print(f"  投递链接: {job['apply_url']}")
    else:
        print("  投递链接: 未开放（注册会员可用）")
    if job.get("notice_url"):
        print(f"  公告链接: {job['notice_url']}")
    if job.get("notice_summary"):
        print(f"  公告摘要: {str(job['notice_summary'])[:200]}")


def cmd_guide(a):
    name = a.position
    data = get(f"/api/guides/{urllib.parse.quote(NAME_TO_SLUG.get(name, name))}")
    print(f"【{data.get('position') or name}】求职攻略（在招 {data.get('job_count', '?')} 条）\n")
    stages = {"overview": "岗位概述", "written": "笔试攻略", "interview": "面试攻略",
              "salary": "薪资情况", "faq": "常见问题", "说明书": "岗位说明书"}
    guides = data.get("guides") or []
    if not guides:
        print("该岗位暂无攻略。")
        return
    for g in guides:
        stage = g.get("stage")
        title = stages.get(stage, stage)
        content = g.get("content") or ""
        print(f"### {title}（{g.get('title') or ''}）")
        print(content[:3000] if content else "（无内容）")
        print()


def cmd_guides(a):
    data = get("/api/guides")
    rows = data.get("list") or []
    print(f"共 {len(rows)} 个岗位有攻略：\n")
    for g in rows:
        print(f"  {g.get('name') or ''}（在招 {g.get('job_count', '?')} 条，攻略 {g.get('gcount', 0)} 篇）")


def cmd_salary(a):
    data = get("/api/offer/reference", {
        "position": a.position, "company": a.company, "city": a.city,
    })
    rows = data.get("list") or []
    if not rows:
        print(f"未找到「{a.position or ''}」的薪资参考。")
        return
    print(f"「{a.position or ''}」薪资参考（单位：千元/月）：\n")
    for s in rows:
        tier = s.get("tier") or "全部"
        edu = s.get("education") or ""
        gy = s.get("grad_year") or ""
        company = s.get("company") or "匿名"
        print(f"  {company}（{edu}，{gy}届，{tier}）：{s.get('salary_min')}-{s.get('salary_max')}k/月")
    print("\n数据来自公开爆料与薪资汇总，仅供参考。")


def cmd_paper(a):
    data = get("/api/practice/paper", {"position": a.position, "size": a.size or 10})
    print(f"【{data.get('position') or a.position}】练习卷（{data.get('written', 0)} 笔试 + {data.get('interview', 0)} 面试）")
    print(f"说明：{data.get('intro') or '-'}\n")
    for q in data.get("questions") or []:
        print(f"[{q.get('exam_stage') or ''}] {q.get('q_type') or ''}：{q.get('stem') or ''}")
        for o in q.get("options") or []:
            print(f"  - {o}")
        print()


def cmd_meta(a):
    data = get("/api/meta")
    print(json.dumps(data, ensure_ascii=False, indent=2))


def main():
    p = argparse.ArgumentParser(prog="xzb", description="校招宝公开 API 客户端")
    sub = p.add_subparsers(dest="cmd", required=True)

    pj = sub.add_parser("jobs", help="查招聘岗位")
    pj.add_argument("--position"); pj.add_argument("--city")
    pj.add_argument("--batch"); pj.add_argument("--industry")
    pj.add_argument("--grad-year", dest="grad_year"); pj.add_argument("--keyword")
    pj.add_argument("--limit", type=int); pj.set_defaults(func=cmd_jobs)

    pd = sub.add_parser("detail", help="查岗位详情")
    pd.add_argument("--id", required=True); pd.set_defaults(func=cmd_detail)

    pg = sub.add_parser("guide", help="查岗位攻略")
    pg.add_argument("--position", required=True); pg.set_defaults(func=cmd_guide)

    pgs = sub.add_parser("guides", help="攻略目录"); pgs.set_defaults(func=cmd_guides)

    ps = sub.add_parser("salary", help="查薪资参考")
    ps.add_argument("--position"); ps.add_argument("--company"); ps.add_argument("--city")
    ps.set_defaults(func=cmd_salary)

    pp = sub.add_parser("paper", help="组练习卷")
    pp.add_argument("--position", required=True); pp.add_argument("--size", type=int)
    pp.set_defaults(func=cmd_paper)

    pm = sub.add_parser("meta", help="筛选项字典"); pm.set_defaults(func=cmd_meta)

    a = p.parse_args()
    a.func(a)


if __name__ == "__main__":
    main()
